(function(){
'use strict';
/* ---------- utilidades ---------- */
const $=(s,r)=>(r||document).querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad=n=>String(n).padStart(2,'0');
const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const parse=s=>{const a=s.split('-').map(Number);return new Date(a[0],a[1]-1,a[2])};
const addDays=(s,n)=>{const d=parse(s);d.setDate(d.getDate()+n);return iso(d)};
const TODAY=()=>iso(new Date());
const fmt=(n,d)=>Number(n).toLocaleString('pt-BR',{minimumFractionDigits:d||0,maximumFractionDigits:d||0});
const r1=n=>Math.round(n*10)/10;
const uid=()=>Math.random().toString(36).slice(2,9);
const num=v=>{const n=parseFloat(String(v).replace(',','.'));return isFinite(n)?n:null};
const DOW=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const DOWF=['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
const MON=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
const dlabel=s=>{const d=parse(s);return DOWF[d.getDay()]+', '+d.getDate()+' '+MON[d.getMonth()]};
const dshort=t=>{const d=new Date(t);return d.getDate()+' '+MON[d.getMonth()]};
const norm=s=>String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
const weekStart=s=>{const d=parse(s);const k=(d.getDay()+6)%7;d.setDate(d.getDate()-k);return iso(d)};
const clone=o=>JSON.parse(JSON.stringify(o));

/* ---------- alimentos (por 100 g): nome, kcal, P, C, G, unidade, g da unidade ---------- */
const FOODS=[
['Arroz branco cozido',128,2.5,28.1,.2,'colher de servir',45],['Arroz integral cozido',124,2.6,25.8,1,'colher de servir',45],
['Feijão carioca cozido',76,4.8,13.6,.5,'concha',80],['Feijão preto cozido',77,4.5,14,.5,'concha',80],['Lentilha cozida',93,6.3,16.3,.5],
['Grão-de-bico cozido',164,8.9,27.4,2.6],['Macarrão cozido',122,4.5,24.5,.9],['Batata-doce cozida',77,.6,18.4,.1],
['Batata inglesa cozida',52,1.2,11.9,0],['Mandioca cozida',125,.6,30.1,.3],['Cuscuz de milho',113,2.2,25.3,.7],
['Tapioca (goma hidratada)',240,0,59,0,'tapioca',40],['Quinoa cozida',120,4.4,21.3,1.9],['Milho cozido',98,3.2,18.6,1.5],
['Pão francês',300,8,58.6,3.1,'unidade',50],['Pão integral',253,9.4,49.9,3.7,'fatia',25],['Pão de queijo',363,5,34.2,22.6,'unidade',30],
['Aveia em flocos',394,13.9,66.6,8.5,'colher de sopa',15],['Granola',421,9,68,12,'colher de sopa',15],
['Peito de frango grelhado',159,32,0,2.5,'filé',120],['Coxa de frango assada sem pele',190,26,0,9],['Frango desfiado cozido',163,31,0,3.5],
['Patinho grelhado',219,35.9,0,7.3,'bife',120],['Alcatra grelhada',241,31.9,0,11.5,'bife',120],['Carne moída refogada',212,26.7,0,10.9],
['Filé de tilápia grelhado',128,26,0,2.7,'filé',120],['Salmão grelhado',229,24,0,14,'posta',130],['Atum em conserva (em água)',116,26,0,1,'lata',120],
['Ovo cozido',146,13.3,.6,9.5,'unidade',50],['Ovo mexido',160,11,1.5,12,'ovo',50],['Clara de ovo',52,11,.7,.2,'clara',33],
['Peito de peru fatiado',105,17,2,3,'fatia',15],['Presunto magro',129,14,1.5,7,'fatia',15],['Tofu',76,8,1.9,4.8],
['Whey protein (pó)',400,80,8,6,'dose',30],
['Leite integral',61,3.2,4.6,3.3,'copo',200],['Leite desnatado',35,3.4,4.9,.1,'copo',200],['Iogurte natural integral',51,4.1,1.9,3,'pote',170],
['Iogurte grego natural',97,9,4,5,'pote',170],['Queijo minas frescal',264,17.4,3.2,20.2,'fatia',30],['Queijo muçarela',330,22.6,3,25.2,'fatia',20],
['Queijo cottage',98,11,3.4,4.3,'colher de sopa',30],['Requeijão light',170,9,4,13,'colher de sopa',30],['Ricota',140,12.6,3.8,8.1,'fatia',40],
['Banana prata',98,1.3,26,.1,'unidade',80],['Maçã',56,.3,15.2,0,'unidade',130],['Laranja',46,1,11.5,.1,'unidade',180],['Mamão papaia',40,.5,10.4,.1,'fatia',100],
['Manga',64,.4,16.7,.3,'unidade',200],['Abacate',96,1.2,6,8.4,'colher de sopa',30],['Morango',30,.9,6.8,.3,'unidade',12],['Uva',53,.7,13.6,.2],
['Melancia',33,.9,8.1,0,'fatia',200],['Abacaxi',48,.9,12.3,.1,'fatia',75],['Pera',53,.6,14,.1,'unidade',150],
['Alface',11,1.3,1.7,.2],['Tomate',15,1.1,3.1,.2,'unidade',100],['Brócolis cozido',25,2.1,4.4,.5],['Cenoura cozida',30,.8,6.7,.2],
['Couve refogada',90,1.7,8.7,6.6],['Abobrinha cozida',15,1.1,3,.2],['Pepino',10,.9,2,.1],['Espinafre cozido',23,2.7,3.8,.3],['Beterraba cozida',32,1.3,7.2,.1],
['Azeite de oliva',884,0,0,100,'colher de sopa',13],['Pasta de amendoim',588,25,20,50,'colher de sopa',15],['Amendoim',567,26,16,49,'punhado',30],
['Castanha-do-pará',643,14.5,15.1,63.5,'unidade',4],['Amêndoas',579,21,22,50,'punhado',28],['Chia',486,17,42,31,'colher de sopa',12],
['Mel',309,.4,84,0,'colher de sopa',21],['Açúcar',387,0,99.5,0,'colher de chá',5],['Chocolate 70% cacau',560,7,46,38,'quadrado',10],
['Café sem açúcar',2,.1,0,0,'xícara',50],['Suco de laranja',45,.7,10.4,.2,'copo',200],['Refrigerante cola',42,0,10.6,0,'lata',350],['Pizza de muçarela',270,11,33,10,'fatia',110]
].map(a=>({n:a[0],k:a[1],p:a[2],c:a[3],f:a[4],ul:a[5]||'',ug:a[6]||0}));

/* ---------- exercícios ---------- */
const GROUPS=['Peito','Costas','Ombros','Bíceps','Tríceps','Quadríceps','Posterior','Glúteos','Panturrilha','Abdômen'];
const EXL={
Peito:['Supino reto com barra','Supino inclinado com barra','Supino reto com halteres','Supino inclinado com halteres','Crucifixo máquina','Crossover na polia','Flexão de braço','Mergulho nas paralelas','Supino declinado'],
Costas:['Puxada frontal','Barra fixa','Remada curvada com barra','Remada baixa','Remada unilateral com halter','Remada cavalinho','Levantamento terra','Pulldown com corda'],
Ombros:['Desenvolvimento com halteres','Desenvolvimento militar','Elevação lateral','Elevação frontal','Crucifixo inverso','Encolhimento','Face pull'],
'Bíceps':['Rosca direta com barra','Rosca alternada com halteres','Rosca martelo','Rosca scott','Rosca concentrada','Rosca na polia'],
'Tríceps':['Tríceps pulley','Tríceps corda','Tríceps testa','Tríceps francês','Mergulho no banco','Tríceps coice'],
'Quadríceps':['Agachamento livre','Leg press 45°','Cadeira extensora','Agachamento hack','Agachamento búlgaro','Afundo','Passada'],
Posterior:['Mesa flexora','Cadeira flexora','Stiff','Levantamento terra romeno'],
'Glúteos':['Elevação pélvica','Cadeira abdutora','Glúteo na polia','Agachamento sumô'],
Panturrilha:['Panturrilha em pé','Panturrilha sentado','Panturrilha no leg press'],
'Abdômen':['Abdominal supra','Abdominal infra','Abdominal na polia','Prancha','Elevação de pernas']};
const EXS=[];GROUPS.forEach(g=>EXL[g].forEach(n=>EXS.push({n:n,g:g})));
const exGroup=n=>{const e=EXS.find(x=>x.n===n);return e?e.g:'Outro'};

function defaultPlans(){
  const W=(id,nome,foco,ex)=>({id:id,nome:nome,foco:foco,ex:ex.map(a=>({n:a[0],g:a[1],s:a[2],r:a[3]}))});
  return {workouts:[
    W('w1','Peito + Tríceps','Empurrar',[['Supino reto com barra','Peito',4,'6-8'],['Supino inclinado com halteres','Peito',3,'8-10'],['Crucifixo máquina','Peito',3,'10-12'],['Tríceps pulley','Tríceps',3,'10-12'],['Tríceps testa','Tríceps',3,'8-10']]),
    W('w2','Costas + Bíceps','Puxar',[['Puxada frontal','Costas',4,'8-10'],['Remada curvada com barra','Costas',4,'6-8'],['Remada baixa','Costas',3,'10-12'],['Rosca direta com barra','Bíceps',3,'8-10'],['Rosca martelo','Bíceps',3,'10-12']]),
    W('w3','Pernas','Inferiores',[['Agachamento livre','Quadríceps',4,'6-8'],['Leg press 45°','Quadríceps',3,'10-12'],['Mesa flexora','Posterior',3,'10-12'],['Stiff','Posterior',3,'8-10'],['Panturrilha em pé','Panturrilha',4,'12-15']]),
    W('w4','Ombros + Abdômen','Ombros e core',[['Desenvolvimento com halteres','Ombros',4,'8-10'],['Elevação lateral','Ombros',4,'12-15'],['Crucifixo inverso','Ombros',3,'12-15'],['Encolhimento','Ombros',3,'10-12'],['Abdominal na polia','Abdômen',3,'12-15']])
  ],week:['','w1','w2','w3','','w4','']};
}

/* ---------- estado ---------- */
const LS='forma:v1',LSS='forma:ses';
let S=null,ui={mealDate:null,tt:'sessao',bm:'kg',br:90,exSel:'',conf:'',ses:null},rest=null;
let dbCol=null,dbOk=false,known=new Set(),dirty=new Set(),saveT=null,touched=false;

function blank(){return {v:1,demo:false,
  profile:{nome:'',sexo:'m',idade:28,altura:175,peso:75,atividade:1.55,objetivo:'manter',pesoMeta:0,gorduraMeta:0,descanso:90,manual:false,kcal:0,prot:0,carb:0,fat:0},
  plans:defaultPlans(),customFoods:[],body:[],logs:[],meals:{},water:{}}}

function docFor(k){
  if(k==='core')return {profile:S.profile,plans:S.plans,customFoods:S.customFoods,demo:S.demo};
  if(k==='body')return {body:S.body};
  if(k.indexOf('logs-')===0){const y=k.slice(5);return {logs:S.logs.filter(l=>l.d.indexOf(y)===0)}}
  if(k.indexOf('m-')===0){const ym=k.slice(2),o={meals:{},water:{}};
    for(const d in S.meals)if(d.indexOf(ym)===0)o.meals[d]=S.meals[d];
    for(const d in S.water)if(d.indexOf(ym)===0)o.water[d]=S.water[d];return o}
  return {};
}
function allKeys(){const k=new Set(['core','body']);
  S.logs.forEach(l=>k.add('logs-'+l.d.slice(0,4)));
  Object.keys(S.meals).concat(Object.keys(S.water)).forEach(d=>k.add('m-'+d.slice(0,7)));return k}
function fromDocs(docs){
  const s=blank();const c=docs.core;
  if(c){Object.assign(s.profile,c.profile||{});if(c.plans&&c.plans.workouts)s.plans=c.plans;s.customFoods=c.customFoods||[];s.demo=!!c.demo}
  if(docs.body)s.body=docs.body.body||[];
  Object.keys(docs).forEach(id=>{
    if(id.indexOf('logs-')===0)s.logs.push.apply(s.logs,docs[id].logs||[]);
    if(id.indexOf('m-')===0){Object.assign(s.meals,docs[id].meals||{});Object.assign(s.water,docs[id].water||{})}});
  s.logs.sort((a,b)=>a.d<b.d?-1:a.d>b.d?1:0);s.body.sort((a,b)=>a.d<b.d?-1:a.d>b.d?1:0);
  return s;
}
function mirror(){try{localStorage.setItem(LS,JSON.stringify(S))}catch(e){}}
function save(){touched=true;for(let i=0;i<arguments.length;i++)dirty.add(arguments[i]);mirror();
  clearTimeout(saveT);saveT=setTimeout(flush,700)}
let flushing=false;
async function flush(){
  if(!dbCol||flushing)return;flushing=true;
  try{while(dirty.size){const k=dirty.values().next().value;dirty.delete(k);
    try{await dbCol.doc(k).set(clone(docFor(k)));known.add(k);dbOk=true}catch(e){dbOk=false;dirty.add(k);break}}}
  finally{flushing=false}
  if(dirty.size&&dbOk===false){clearTimeout(saveT);saveT=setTimeout(flush,8000)}
}
function withTimeout(p,ms){return Promise.race([p,new Promise((_,rj)=>setTimeout(()=>rj(new Error('timeout')),ms))])}
async function connect(){
  try{
    const c=window.claude;if(!c||!c.use)return;
    const db=await c.use('db'),user=await c.use('user');
    if(!db||!user)return;
    const id=await user.id();if(!id)return;
    dbCol=db.collection('data/users/'+id);
    const snap=await withTimeout(dbCol.get(),9000);
    if(touched){allKeys().forEach(k=>dirty.add(k));dbOk=true;flush()}
    else if(!snap.empty){const docs={};snap.docs.forEach(d=>{docs[d.id]=d.data();known.add(d.id)});S=fromDocs(docs);dbOk=true;mirror();render()}
  }catch(e){dbOk=false}
}

/* ---------- cálculos ---------- */
const SLOTS=[['cafe','Café da manhã'],['almoco','Almoço'],['lanche','Lanche'],['jantar','Jantar'],['ceia','Ceia']];
const OBJ={perder:'Perder gordura',manter:'Manter',ganhar:'Ganhar massa'};
const ACT=[[1.2,'Sedentário'],[1.375,'Leve (1–3 treinos/sem)'],[1.55,'Moderado (3–5 treinos/sem)'],[1.725,'Alto (6–7 treinos/sem)'],[1.9,'Muito alto (2x ao dia)']];
const lastWith=k=>{for(let i=S.body.length-1;i>=0;i--)if(S.body[i][k]!=null&&S.body[i][k]!=='')return S.body[i];return null};
const curWeight=()=>{const b=lastWith('kg');return b?b.kg:S.profile.peso};
const curBF=()=>{const b=lastWith('bf');return b?b.bf:null};
function calc(){
  const p=S.profile,w=curWeight();
  const bmr=10*w+6.25*p.altura-5*p.idade+(p.sexo==='m'?5:-161);
  const tdee=bmr*p.atividade;
  const adj={perder:.8,manter:1,ganhar:1.1}[p.objetivo]||1;
  let kcal=Math.round(tdee*adj/10)*10;
  let prot=Math.round(w*(p.objetivo==='perder'?2.2:1.9)),fat=Math.round(w*.9);
  let carb=Math.max(0,Math.round((kcal-prot*4-fat*9)/4));
  const auto={kcal:kcal,prot:prot,carb:carb,fat:fat};
  if(p.manual){kcal=p.kcal||kcal;prot=p.prot||prot;fat=p.fat||fat;carb=p.carb||carb}
  return {bmr:bmr,tdee:tdee,kcal:kcal,prot:prot,carb:carb,fat:fat,agua:Math.round(w*35/50)*50,w:w,auto:auto};
}
const dayItems=d=>{const m=S.meals[d]||{};return SLOTS.reduce((a,s)=>a.concat(m[s[0]]||[]),[])};
const sum=items=>items.reduce((a,i)=>({k:a.k+i.k,p:a.p+i.p,c:a.c+i.c,f:a.f+i.f}),{k:0,p:0,c:0,f:0});
function mk(food,g){const x=g/100;return {n:food.n,g:g,k:Math.round(food.k*x),p:r1(food.p*x),c:r1(food.c*x),f:r1(food.f*x)}}
const allFoods=()=>FOODS.concat(S.customFoods.map(f=>({n:f.n,k:f.k,p:f.p,c:f.c,f:f.f,ul:'',ug:0,custom:true})));
const bodyVal=(e,k)=>{
  if(k==='mm')return e.kg&&e.bf!=null&&e.bf!==''?r1(e.kg*(1-e.bf/100)):null;
  if(k==='mg')return e.kg&&e.bf!=null&&e.bf!==''?r1(e.kg*e.bf/100):null;
  const v=e[k];return v===''||v==null?null:v};
function navy(sexo,h,cin,pes,quad){
  if(!cin||!pes||!h)return null;
  if(sexo==='m'){const v=cin-pes;if(v<=0)return null;return 495/(1.0324-.19077*Math.log10(v)+.15456*Math.log10(h))-450}
  if(!quad)return null;const v=cin+quad-pes;if(v<=0)return null;
  return 495/(1.29579-.35004*Math.log10(v)+.221*Math.log10(h))-450}
function bfLabel(bf){if(bf==null)return '';const m=S.profile.sexo==='m';
  const t=m?[6,14,18,25]:[14,21,25,32];
  return bf<t[0]?'Essencial':bf<t[1]?'Atlético':bf<t[2]?'Fitness':bf<t[3]?'Médio':'Acima da média'}
function imcLabel(v){return v<18.5?'Abaixo do peso':v<25?'Faixa normal':v<30?'Sobrepeso':'Obesidade'}
const e1rm=(kg,r)=>r<=1?kg:kg*(1+r/30);
function streak(){let n=0,d=TODAY();
  const has=x=>dayItems(x).length||S.logs.some(l=>l.d===x)||S.body.some(b=>b.d===x);
  if(!has(d))d=addDays(d,-1);
  while(n<400&&has(d)){n++;d=addDays(d,-1)}return n}
function lastSets(name){
  for(let i=S.logs.length-1;i>=0;i--){const e=S.logs[i].ex.find(x=>x.n===name);if(e&&e.sets.length)return e.sets}
  return null}
function bestE1(name,before){
  let b=0;S.logs.forEach(l=>{if(before&&l.d>=before)return;l.ex.forEach(e=>{if(e.n===name)e.sets.forEach(s=>{b=Math.max(b,e1rm(s.kg,s.r))})})});return b}

/* ---------- dados de exemplo ---------- */
function demo(){
  const s=blank();s.demo=true;const t=TODAY();
  Object.assign(s.profile,{nome:'Atleta',sexo:'m',idade:29,altura:178,peso:83,atividade:1.55,objetivo:'perder',pesoMeta:78,gorduraMeta:12});
  const nz=i=>((i*37)%7-3)*.09;
  for(let i=8;i>=0;i--){const k=8-i;
    s.body.push({d:addDays(t,-i*7),kg:r1(84-k*.42+nz(i)),bf:r1(18.6-k*.3+nz(i)),cintura:r1(90-k*.6),peito:r1(104+k*.15),braco:r1(36+k*.1),coxa:r1(60+k*.1),quadril:r1(100-k*.2),pescoco:38,panturrilha:r1(38+k*.05)})}
  const base={Peito:50,Costas:55,Ombros:16,'Bíceps':14,'Tríceps':25,'Quadríceps':100,Posterior:45,'Glúteos':60,Panturrilha:70,'Abdômen':35};
  for(let i=28;i>=1;i--){const d=addDays(t,-i),dow=parse(d).getDay(),w=s.plans.workouts.find(x=>x.id===s.plans.week[dow]);if(!w)continue;
    const wk=(28-i)/7;
    const ex=w.ex.map((e,j)=>{const kg=Math.round((base[e.g]||30)*(1+wk*.015)*(1-j*.04)/2.5)*2.5;
      const reps=parseInt(e.r)||8;const sets=[];for(let n=0;n<e.s;n++)sets.push({kg:kg,r:Math.max(5,reps+1-(n>1?1:0)-(n===e.s-1?1:0)+(wk>2?1:0))});
      return {n:e.n,g:e.g,sets:sets}});
    const vol=ex.reduce((a,e)=>a+e.sets.reduce((b,x)=>b+x.kg*x.r,0),0);
    s.logs.push({id:uid(),d:d,wid:w.id,nome:w.nome,dur:52+(i*7)%15,vol:Math.round(vol),ex:ex})}
  const F=n=>FOODS.find(f=>f.n===n);
  const tpl={cafe:[['Ovo mexido',100],['Pão integral',50],['Banana prata',100],['Café sem açúcar',100]],
    almoco:[['Arroz branco cozido',150],['Feijão carioca cozido',100],['Peito de frango grelhado',150],['Brócolis cozido',80],['Azeite de oliva',8]],
    lanche:[['Iogurte grego natural',170],['Aveia em flocos',30],['Morango',100]],
    jantar:[['Batata-doce cozida',200],['Filé de tilápia grelhado',150],['Alface',60],['Azeite de oliva',6]],
    ceia:[['Queijo cottage',100]]};
  for(let i=6;i>=0;i--){const d=addDays(t,-i);s.meals[d]={};
    SLOTS.forEach(sl=>{if(i===0&&(sl[0]==='lanche'||sl[0]==='jantar'||sl[0]==='ceia'))return;
      s.meals[d][sl[0]]=tpl[sl[0]].map((a,j)=>mk(F(a[0]),Math.round(a[1]*(1+(((i+j)*5)%7-3)*.04))))});
    s.water[d]=i===0?750:1800+((i*370)%900)}
  return s;
}

/* ---------- gráficos ---------- */
const ICO={home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  meals:'<path d="M7 3v8a2 2 0 0 0 2 2v8"/><path d="M5 3v6"/><path d="M11 3v6"/><path d="M17 21V3c-2 1-3.500 4-3.500 8 0 2 1.200 3 3.500 3"/>',
  dumb:'<path d="M6.500 6.500v11M17.500 6.500v11M3 9v6M21 9v6M6.500 12h11"/>',
  scale:'<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M8 10a5 5 0 0 1 8 0"/><path d="M12 10l2-2.500"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>'};
const ico=n=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+ICO[n]+'</svg>';
let CH=[],chN=0;
function chart(fn,h){const id='ch'+(++chN);CH.push({id:id,fn:fn});return '<div class="chart" id="'+id+'" style="min-height:'+(h||160)+'px"></div>'}
function drawCharts(){CH.forEach(c=>{const el=document.getElementById(c.id);if(el)el.innerHTML=c.fn(Math.max(240,Math.floor(el.clientWidth)))})}
function nice(lo,hi,n){const span=hi-lo,raw=span/n,mag=Math.pow(10,Math.floor(Math.log10(raw))),f=raw/mag;
  const step=(f<1.5?1:f<3?2:f<7?5:10)*mag,a=Math.floor(lo/step+1e-9)*step,b=Math.ceil(hi/step-1e-9)*step,t=[];
  for(let v=a;v<=b+step/2;v+=step)t.push(Math.round(v*1e6)/1e6);return {a:a,b:b,t:t}}
function svgLine(W,H,pts,o){
  o=o||{};if(!pts.length)return '<div class="empty">Sem registros neste período.</div>';
  const m={l:o.ml||40,r:18,t:18,b:26};
  let x0=Math.min.apply(null,pts.map(p=>p.t)),x1=Math.max.apply(null,pts.map(p=>p.t));if(x0===x1){x0-=2592e5;x1+=2592e5}
  const ys=pts.map(p=>p.y);if(o.goal)ys.push(o.goal);if(o.tr)o.tr.forEach(p=>ys.push(p.y));
  let lo=Math.min.apply(null,ys),hi=Math.max.apply(null,ys);if(lo===hi){lo-=1;hi+=1}
  const pd=(hi-lo)*.14;lo-=pd;hi+=pd;const sc=nice(lo,hi,4);
  const X=t=>m.l+(t-x0)/(x1-x0)*(W-m.l-m.r),Y=v=>H-m.b-(v-sc.a)/(sc.b-sc.a)*(H-m.t-m.b);
  const dec=o.dec==null?1:o.dec;let s='<svg viewBox="0 0 '+W+' '+H+'" width="'+W+'" height="'+H+'" role="img">';
  sc.t.forEach(v=>{s+='<line class="grid-l" x1="'+m.l+'" x2="'+(W-m.r)+'" y1="'+Y(v)+'" y2="'+Y(v)+'"/><text class="ax" x="'+(m.l-8)+'" y="'+(Y(v)+4)+'" text-anchor="end">'+fmt(v,sc.t[1]-sc.t[0]<1?1:0)+'</text>'});
  const nx=Math.min(5,Math.max(2,Math.floor((W-m.l-m.r)/90)));
  for(let i=0;i<nx;i++){const t=x0+(x1-x0)*i/(nx-1);s+='<text class="ax" x="'+X(t)+'" y="'+(H-6)+'" text-anchor="'+(i===0?'start':i===nx-1?'end':'middle')+'">'+dshort(t)+'</text>'}
  if(o.goal)s+='<line class="gl" x1="'+m.l+'" x2="'+(W-m.r)+'" y1="'+Y(o.goal)+'" y2="'+Y(o.goal)+'"/><text class="gt" x="'+(W-m.r)+'" y="'+(Y(o.goal)-6)+'" text-anchor="end">meta '+fmt(o.goal,dec)+'</text>';
  const P=pts.map(p=>X(p.t).toFixed(1)+','+Y(p.y).toFixed(1));
  if(pts.length>1)s+='<path class="ar" d="M'+P.join(' L')+' L'+X(pts[pts.length-1].t)+','+Y(sc.a)+' L'+X(pts[0].t)+','+Y(sc.a)+' Z"/>';
  if(o.tr&&o.tr.length>1)s+='<path class="tr" d="M'+o.tr.map(p=>X(p.t).toFixed(1)+','+Y(p.y).toFixed(1)).join(' L')+'"/>';
  if(pts.length>1)s+='<path class="ln" d="M'+P.join(' L')+'"/>';
  if(pts.length<=40)pts.slice(0,-1).forEach(p=>{s+='<circle class="dt" cx="'+X(p.t)+'" cy="'+Y(p.y)+'" r="3"/>'});
  const L=pts[pts.length-1];
  s+='<circle class="dl" cx="'+X(L.t)+'" cy="'+Y(L.y)+'" r="5.500"/><text class="vl" x="'+Math.min(W-m.r,X(L.t)+4)+'" y="'+(Y(L.y)-12)+'" text-anchor="end">'+fmt(L.y,dec)+'</text></svg>';
  return s}
function svgBars(W,H,items,o){
  o=o||{};const m={l:o.ml||38,r:6,t:14,b:24};
  const mx=Math.max(o.target||0,Math.max.apply(null,items.map(i=>i.v)),1)*1.08,sc=nice(0,mx,3);
  const Y=v=>H-m.b-v/sc.b*(H-m.t-m.b),bw=(W-m.l-m.r)/items.length,w=Math.min(36,bw*.62);
  let s='<svg viewBox="0 0 '+W+' '+H+'" width="'+W+'" height="'+H+'" role="img">';
  sc.t.forEach(v=>{s+='<line class="grid-l" x1="'+m.l+'" x2="'+(W-m.r)+'" y1="'+Y(v)+'" y2="'+Y(v)+'"/><text class="ax" x="'+(m.l-8)+'" y="'+(Y(v)+4)+'" text-anchor="end">'+fmt(v)+'</text>'});
  items.forEach((it,i)=>{const cx=m.l+bw*i+bw/2,h=Math.max(it.v>0?2:0,(H-m.b-Y(it.v)));
    s+='<rect class="'+(it.hi?'brh':'br')+'" x="'+(cx-w/2)+'" y="'+(H-m.b-h)+'" width="'+w+'" height="'+h+'" rx="3"/><text class="ax" x="'+cx+'" y="'+(H-6)+'" text-anchor="middle">'+esc(it.l)+'</text>'});
  if(o.target)s+='<line class="gl" x1="'+m.l+'" x2="'+(W-m.r)+'" y1="'+Y(o.target)+'" y2="'+Y(o.target)+'"/><text class="gt" x="'+(W-m.r)+'" y="'+(Y(o.target)-6)+'" text-anchor="end">meta '+fmt(o.target)+'</text>';
  return s+'</svg>'}
function ring(pct,label,sub){
  const sz=176,st=14,r=(sz-st)/2,C=2*Math.PI*r,d=C*Math.min(1,Math.max(0,pct));
  return '<div class="ring"><svg viewBox="0 0 '+sz+' '+sz+'"><circle cx="'+sz/2+'" cy="'+sz/2+'" r="'+r+'" fill="none" stroke="var(--surface2)" stroke-width="'+st+'"/><circle cx="'+sz/2+'" cy="'+sz/2+'" r="'+r+'" fill="none" stroke="var(--accent)" stroke-width="'+st+'" stroke-linecap="round" stroke-dasharray="'+d+' '+C+'" transform="rotate(-90 '+sz/2+' '+sz/2+')"/></svg><div class="c"><div class="num">'+label+'</div><div class="sm muted">'+sub+'</div></div></div>'}
const pctOf=(v,g)=>g>0?Math.min(100,v/g*100):0;
function macroBars(T,g){
  const row=(l,v,t,c)=>'<div class="mac"><div class="t"><span>'+l+'</span><span class="tn">'+fmt(v)+' / '+fmt(t)+' g</span></div><div class="bar '+c+'"><i style="width:'+pctOf(v,t)+'%"></i></div></div>';
  return '<div class="macros">'+row('Proteína',T.p,g.prot,'')+row('Carboidrato',T.c,g.carb,'c')+row('Gordura',T.f,g.fat,'f')+'</div>'}
function waterCard(d,g){
  const w=S.water[d]||0;
  return '<article class="card"><h2 class="lab"><span>Água</span><span class="tn">'+fmt(w/1000,2)+' / '+fmt(g.agua/1000,2)+' L</span></h2>'+
  '<div class="bar w" style="height:12px"><i style="width:'+pctOf(w,g.agua)+'%"></i></div>'+
  '<div class="row" style="margin-top:16px"><button class="btn sec sm" data-a="water" data-d="'+d+'" data-n="-250">−250 ml</button><button class="btn sm" data-a="water" data-d="'+d+'" data-n="250">+250 ml</button><button class="btn sm" data-a="water" data-d="'+d+'" data-n="500">+500 ml</button></div></article>'}
function calCard(d,g,compact){
  const T=sum(dayItems(d)),left=g.kcal-T.k;
  return '<article class="card"><h2 class="lab"><span>Calorias</span><span>meta '+fmt(g.kcal)+' kcal</span></h2><div class="cal">'+
  ring(g.kcal?T.k/g.kcal:0,fmt(Math.abs(left)),left>=0?'kcal restantes':'kcal acima')+
  '<div style="flex:1;min-width:200px"><div class="kv"><div><b>'+fmt(T.k)+'</b><span>Consumido</span></div><div><b>'+fmt(g.kcal)+'</b><span>Meta</span></div><div><b>'+fmt(T.p*4+T.c*4+T.f*9)+'</b><span>Pelos macros</span></div></div>'+macroBars(T,g)+'</div></div></article>'}

/* ---------- telas ---------- */
const ROUTES=[['hoje','Hoje','home'],['refeicoes','Refeições','meals'],['treinos','Treinos','dumb'],['corpo','Corpo','scale'],['perfil','Perfil','user']];
const route=()=>{const h=(location.hash||'').slice(1);return ROUTES.some(r=>r[0]===h)?h:'hoje'};
const demoBar=()=>S.demo?'<div class="demo"><span><b>Dados de exemplo.</b> Eles mostram como o app funciona.</span><span class="sp"></span><button class="btn sm" data-a="clear-demo">Começar do zero</button></div>':'';

function vHoje(){
  const t=TODAY(),g=calc(),p=S.profile,h=new Date().getHours();
  const sal=h<12?'Bom dia':h<18?'Boa tarde':'Boa noite',nm=p.nome?', '+esc(p.nome):'';
  const dow=parse(t).getDay(),wid=S.plans.week[dow],w=S.plans.workouts.find(x=>x.id===wid);
  const done=S.logs.find(l=>l.d===t),b0=S.body.length?S.body[0]:null,wn=curWeight(),bf=curBF();
  const dw=b0?wn-b0.kg:0;
  let h1='<section class="hero"><div><div class="eyebrow">'+dlabel(t)+'</div><h1 class="display">'+sal+nm+'</h1><p class="hero-sub">'+
   (done?'Treino de hoje concluído: '+esc(done.nome)+'.':w?'Hoje é dia de '+esc(w.nome)+'. '+w.ex.length+' exercícios no plano.':'Hoje é dia de descanso. Foque em comer e dormir bem.')+'</p>'+
   '<div class="row">'+(w&&!done?'<button class="btn" data-a="start" data-w="'+w.id+'">Iniciar treino</button>':'')+'<a class="btn sec" href="#refeicoes">Registrar refeição</a></div></div>'+
   '<dl class="hero-stats"><div><dt>Peso</dt><dd>'+fmt(wn,1)+'<small>kg</small></dd></div><div><dt>Gordura</dt><dd>'+(bf!=null?fmt(bf,1)+'<small>%</small>':'—')+'</dd></div><div><dt>Sequência</dt><dd>'+streak()+'<small>dias</small></dd></div></dl></section>';
  let h2='<div class="grid"><div class="s7">'+calCard(t,g)+'</div><div class="s5 stack">'+waterCard(t,g)+weekCard()+'</div>';
  const ws=S.body.slice(-12).map(b=>({t:parse(b.d).getTime(),y:b.kg}));
  h2+='<div class="s6"><article class="card"><h2 class="lab"><span>Peso</span><span class="tn">'+(b0?(dw>0?'+':'')+fmt(dw,1)+' kg desde o início':'')+'</span></h2>'+chart(W=>svgLine(W,200,ws,{goal:p.pesoMeta||0}),200)+'</article></div>';
  const wv=weekVol();
  h2+='<div class="s6"><article class="card"><h2 class="lab"><span>Volume por semana (kg)</span></h2>'+chart(W=>svgBars(W,200,wv,{ml:46}),200)+'</article></div></div>';
  return h1+h2}
function weekCard(){
  const ws=weekStart(TODAY()),t=TODAY();let c='';
  for(let i=0;i<7;i++){const d=addDays(ws,i),dow=parse(d).getDay(),w=S.plans.workouts.find(x=>x.id===S.plans.week[dow]),ok=S.logs.some(l=>l.d===d);
    c+='<div class="'+(d===t?'t':'')+'"><span class="d">'+DOW[dow]+'</span><span class="w">'+(w?esc(w.nome.split(' + ')[0]):'Folga')+'</span>'+(ok?'<span class="dn">✓</span>':'<span class="no"></span>')+'</div>'}
  return '<article class="card"><h2 class="lab"><span>Semana</span></h2><div class="wk">'+c+'</div></article>'}
function weekVol(){
  const cur=weekStart(TODAY()),o=[];
  for(let i=7;i>=0;i--){const a=addDays(cur,-i*7),b=addDays(a,7);
    o.push({l:dshort(parse(a).getTime()),v:Math.round(S.logs.filter(l=>l.d>=a&&l.d<b).reduce((s,l)=>s+l.vol,0)/10)/100*10,hi:i===0})}
  return o.map(x=>({l:x.l,v:Math.round(x.v),hi:x.hi}))}

function vRef(){
  const d=ui.mealDate||(ui.mealDate=TODAY()),g=calc(),m=S.meals[d]||{};let sl='';
  SLOTS.forEach(s=>{const it=m[s[0]]||[],T=sum(it);
    sl+='<section class="slot"><header><h3>'+s[1]+'</h3><span class="kc">'+fmt(T.k)+' kcal</span></header>'+
    (it.length?it.map((x,i)=>'<div class="item"><div><div class="nm">'+esc(x.n)+'</div><div class="mt tn">'+fmt(x.g)+' g · P '+fmt(x.p,1)+' · C '+fmt(x.c,1)+' · G '+fmt(x.f,1)+'</div></div><span class="kc tn">'+x.k+'</span><button class="ib" aria-label="Remover '+esc(x.n)+'" data-a="rm-food" data-d="'+d+'" data-s="'+s[0]+'" data-i="'+i+'">×</button></div>').join(''):'<div class="item muted sm">Nada registrado.</div>')+
    '<button class="add" data-a="add-food" data-s="'+s[0]+'">+ Adicionar alimento</button></section>'});
  return '<div class="page-h"><h1 class="display">Refeições</h1><div class="datenav"><button class="ib" data-a="dnav" data-n="-1" aria-label="Dia anterior">‹</button><input type="date" id="mdate" value="'+d+'" aria-label="Data"><button class="ib" data-a="dnav" data-n="1" aria-label="Próximo dia">›</button>'+(d!==TODAY()?'<button class="btn sec sm" data-a="dnav" data-n="0">Hoje</button>':'')+'</div></div>'+demoBar()+
  '<div class="grid"><div class="s7">'+sl+'</div><div class="s5 stack">'+calCard(d,g)+waterCard(d,g)+refWeek(g)+'</div></div>'}
function refWeek(g){
  const it=[];for(let i=6;i>=0;i--){const d=addDays(TODAY(),-i);it.push({l:DOW[parse(d).getDay()],v:sum(dayItems(d)).k,hi:d===(ui.mealDate||TODAY())})}
  return '<article class="card"><h2 class="lab"><span>Calorias, 7 dias</span></h2>'+chart(W=>svgBars(W,190,it,{target:g.kcal,ml:46}),190)+'</article>'}

function vTre(){
  const tabs=[['sessao','Treino do dia'],['plano','Planos'],['hist','Histórico'],['prog','Progressão']];
  let h='<div class="page-h"><h1 class="display">Treinos</h1></div>'+demoBar()+'<div class="tabs" role="tablist">'+tabs.map(t=>'<button role="tab" class="'+(ui.tt===t[0]?'on':'')+'" data-a="tt" data-t="'+t[0]+'">'+t[1]+'</button>').join('')+'</div>';
  return h+({sessao:tSes,plano:tPlano,hist:tHist,prog:tProg}[ui.tt]||tSes)()}
function sesBody(){
  const s=ui.ses;
  return '<div class="row" style="margin-bottom:16px"><div><div class="eyebrow">Em andamento · '+dlabel(s.d)+'</div><h2 class="display" style="font-size:44px">'+esc(s.nome)+'</h2></div><span class="sp"></span><button class="btn sec" data-a="cancel-ses">Cancelar</button><button class="btn acc" data-a="finish">Finalizar treino</button></div>'+
  s.ex.map((e,i)=>{const last=lastSets(e.n);
    return '<article class="ex"><header><div><h3>'+esc(e.n)+'</h3><span class="tag">'+esc(e.g)+(e.r?' · alvo '+esc(e.r)+' reps':'')+'</span></div><button class="ib" aria-label="Remover exercício" data-a="rm-sx" data-i="'+i+'">×</button></header>'+
    '<p class="last">'+(last?'Última vez: '+last.map(x=>fmt(x.kg,1)+'×'+x.r).join(' · '):'Primeira vez neste exercício.')+'</p>'+
    '<div class="set h"><span>#</span><span>Carga (kg)</span><span>Reps</span><span></span></div>'+
    e.sets.map((x,j)=>'<div class="set'+(x.ok?' ok':'')+'"><span class="si">'+(j+1)+'</span><input inputmode="decimal" aria-label="Carga série '+(j+1)+'" data-a="si" data-i="'+i+'" data-j="'+j+'" data-f="kg" value="'+(x.kg===''?'':x.kg)+'" placeholder="'+(last&&last[j]?last[j].kg:last&&last.length?last[last.length-1].kg:'0')+'"><input inputmode="numeric" aria-label="Repetições série '+(j+1)+'" data-a="si" data-i="'+i+'" data-j="'+j+'" data-f="r" value="'+(x.r===''?'':x.r)+'" placeholder="'+(last&&last[j]?last[j].r:'0')+'"><button class="chk" aria-label="Concluir série '+(j+1)+'" data-a="chk" data-i="'+i+'" data-j="'+j+'">✓</button></div>').join('')+
    '<div class="row" style="margin-top:6px"><button class="btn sec sm" data-a="add-set" data-i="'+i+'">+ Série</button></div></article>'}).join('')+
  '<div class="row"><button class="btn sec" data-a="add-sx">+ Exercício</button></div>'}
function tSes(){
  if(ui.ses)return sesBody();
  const t=TODAY(),dow=parse(t).getDay(),w=S.plans.workouts.find(x=>x.id===S.plans.week[dow]),done=S.logs.find(l=>l.d===t);
  let h='<div class="grid"><div class="s7">';
  if(done)h+='<article class="card"><h2 class="lab"><span>Hoje</span></h2><h3 class="display" style="font-size:44px">'+esc(done.nome)+'</h3><p class="muted" style="margin:8px 0 0">Concluído: '+done.ex.length+' exercícios, '+fmt(done.vol)+' kg de volume.</p></article>';
  else if(w)h+='<article class="card"><h2 class="lab"><span>Plano de hoje</span></h2><h3 class="display" style="font-size:44px;margin-bottom:12px">'+esc(w.nome)+'</h3>'+w.ex.map(e=>'<div class="item"><div class="nm">'+esc(e.n)+'</div><span class="kc muted">'+e.s+' × '+esc(e.r)+'</span></div>').join('')+'<div class="row" style="margin-top:18px"><button class="btn" data-a="start" data-w="'+w.id+'">Iniciar treino</button></div></article>';
  else h+='<article class="card"><h2 class="lab"><span>Hoje</span></h2><h3 class="display" style="font-size:44px">Descanso</h3><p class="muted" style="margin:8px 0 0">Nenhum treino no plano de hoje. Você pode treinar mesmo assim.</p></article>';
  h+='</div><div class="s5 stack"><article class="card"><h2 class="lab"><span>Iniciar outro treino</span></h2><div class="stack" style="gap:8px">'+S.plans.workouts.map(x=>'<button class="btn sec" style="justify-content:space-between" data-a="start" data-w="'+x.id+'"><span>'+esc(x.nome)+'</span><span class="muted">'+x.ex.length+' ex.</span></button>').join('')+'<button class="btn sec" data-a="start" data-w="livre">Treino livre</button></div></article>'+heatCard()+'</div></div>';
  return h}
function heatCard(){
  const set={};S.logs.forEach(l=>set[l.d]=1);const t=TODAY(),n=15,st=addDays(weekStart(t),-(n-1)*7);let c='';
  for(let i=0;i<n*7;i++){const d=addDays(st,i);c+=d>t?'<i style="opacity:.25"></i>':'<i class="'+(set[d]?'l1':'')+(d===t?' t':'')+'" title="'+d+'"></i>'}
  const mo=S.logs.filter(l=>l.d>=addDays(t,-30)).length;
  return '<article class="card"><h2 class="lab"><span>Constância</span><span>'+mo+' treinos em 30 dias</span></h2><div class="heat">'+c+'</div></article>'}
function tPlano(){
  const dias=['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],idx=[1,2,3,4,5,6,0];
  let h='<div class="grid"><div class="s5"><article class="card"><h2 class="lab"><span>Semana</span></h2><div class="stack" style="gap:10px">'+idx.map((di,k)=>'<label class="fld"><span>'+dias[k]+'</span><select class="sel" id="wk'+di+'" data-a="wk" data-di="'+di+'"><option value="">Descanso</option>'+S.plans.workouts.map(w=>'<option value="'+w.id+'"'+(S.plans.week[di]===w.id?' selected':'')+'>'+esc(w.nome)+'</option>').join('')+'</select></label>').join('')+'</div></article></div><div class="s7">';
  S.plans.workouts.forEach(w=>{
    h+='<article class="card" style="margin-bottom:12px"><div class="row" style="margin-bottom:8px"><div style="min-width:0"><h3 class="display" style="font-size:34px">'+esc(w.nome)+'</h3><span class="muted sm">'+esc(w.foco||'')+'</span></div><span class="sp"></span><button class="btn sec sm" data-a="edit-w" data-w="'+w.id+'">Editar</button></div>'+
    w.ex.map(e=>'<div class="item"><div class="nm">'+esc(e.n)+'</div><span class="kc muted">'+e.s+' × '+esc(e.r)+'</span></div>').join('')+'</article>'});
  return h+'<button class="btn" data-a="new-w">+ Novo treino</button></div></div>'}
function tHist(){
  if(!S.logs.length)return '<div class="empty">Nenhum treino finalizado ainda. Inicie um treino para começar o histórico.</div>';
  const grp={};
  return S.logs.slice().reverse().slice(0,60).map(l=>{
    const tt=l.ex.reduce((a,e)=>a+e.sets.length,0);
    return '<details class="hist"><summary><div style="min-width:0;flex:1"><div class="hd">'+esc(l.nome)+'</div><div class="muted sm">'+dlabel(l.d)+' · '+l.dur+' min · '+tt+' séries · '+fmt(l.vol)+' kg</div></div><span class="muted">▾</span></summary><div class="bd">'+
    l.ex.map(e=>'<p><b>'+esc(e.n)+'</b> <span class="muted tn">'+e.sets.map(s=>fmt(s.kg,1)+'×'+s.r).join(' · ')+'</span></p>').join('')+
    '<div class="row" style="margin-top:10px"><button class="btn dng sm" data-a="del-log" data-id="'+l.id+'">Excluir treino</button></div></div></details>'}).join('')}
function tProg(){
  const names=[];S.logs.forEach(l=>l.ex.forEach(e=>{if(names.indexOf(e.n)<0)names.push(e.n)}));
  if(!names.length)return '<div class="empty">A progressão aparece depois do primeiro treino finalizado.</div>';
  names.sort((a,b)=>a.localeCompare(b,'pt-BR'));
  if(!ui.exSel||names.indexOf(ui.exSel)<0)ui.exSel=names[0];
  const pts=[];S.logs.forEach(l=>{l.ex.forEach(e=>{if(e.n===ui.exSel&&e.sets.length){const b=Math.max.apply(null,e.sets.map(s=>e1rm(s.kg,s.r)));pts.push({t:parse(l.d).getTime(),y:Math.round(b*10)/10})}})});
  const pr=Math.max.apply(null,pts.map(p=>p.y)),first=pts[0]?pts[0].y:0,lastv=pts.length?pts[pts.length-1].y:0;
  const vg={};S.logs.filter(l=>l.d>=addDays(TODAY(),-28)).forEach(l=>l.ex.forEach(e=>{vg[e.g]=(vg[e.g]||0)+e.sets.length}));
  const mx=Math.max.apply(null,Object.keys(vg).map(k=>vg[k]).concat([1]));
  return '<div class="grid"><div class="s8"><article class="card"><div class="row" style="margin-bottom:12px"><label class="fld" style="flex:1;min-width:220px"><span>Exercício</span><select class="sel big-sel" id="exsel" data-a="exsel">'+names.map(n=>'<option'+(n===ui.exSel?' selected':'')+'>'+esc(n)+'</option>').join('')+'</select></label></div>'+
   '<h2 class="lab"><span>Carga estimada de 1 repetição (kg)</span></h2>'+chart(W=>svgLine(W,230,pts,{ml:46}),230)+'<p class="note" style="margin-top:8px">Estimativa pela fórmula de Epley (carga × (1 + reps ÷ 30)).</p></article></div>'+
   '<div class="s4 stack"><article class="card"><div class="statrow"><div class="stat"><span class="lab">Recorde</span><span class="num">'+fmt(pr,1)+'<small>kg</small></span></div><div class="stat"><span class="lab">Evolução</span><span class="num '+(lastv>=first?'up':'dn2')+'">'+(lastv>=first?'+':'')+fmt(lastv-first,1)+'<small>kg</small></span></div></div></article>'+
   '<article class="card"><h2 class="lab"><span>Séries por grupo, 4 semanas</span></h2>'+Object.keys(vg).sort((a,b)=>vg[b]-vg[a]).map(k=>'<div class="hbar"><span>'+esc(k)+'</span><div class="bar"><i style="width:'+vg[k]/mx*100+'%"></i></div><span class="tn">'+vg[k]+'</span></div>').join('')+'</article></div></div>'}

/* ---------- corpo ---------- */
const BM=[['kg','Peso','kg'],['bf','Gordura','%'],['mm','Massa magra','kg'],['mg','Massa gorda','kg'],['cintura','Cintura','cm'],['peito','Peito','cm'],['braco','Braço','cm'],['coxa','Coxa','cm'],['quadril','Quadril','cm'],['pescoco','Pescoço','cm'],['panturrilha','Panturrilha','cm']];
function vCorpo(){
  const p=S.profile,n=S.body.length,last=n?S.body[n-1]:null,prev=n>1?S.body[n-2]:null;
  const wn=curWeight(),bf=curBF(),imc=wn/Math.pow(p.altura/100,2);
  const dl=(k)=>{if(!last||!prev)return '';const a=bodyVal(last,k),b=bodyVal(prev,k);if(a==null||b==null)return '';const d=a-b;return '<span class="dl '+(d===0?'muted':(k==='mm'?d>0:d<0)?'up':'dn2')+'">'+(d>0?'+':'')+fmt(d,1)+' desde a última</span>'};
  const mmN=last&&bodyVal(last,'mm')!=null?bodyVal(last,'mm'):null;
  const lm=lastWith('bf');const mmv=lm?bodyVal(lm,'mm'):null;
  let h='<div class="page-h"><h1 class="display">Corpo</h1></div>'+demoBar();
  h+='<div class="grid"><div class="s12"><article class="card"><div class="statrow">'+
   '<div class="stat"><span class="lab">Peso</span><span class="num">'+fmt(wn,1)+'<small>kg</small></span>'+dl('kg')+'</div>'+
   '<div class="stat"><span class="lab">Gordura corporal</span><span class="num">'+(bf!=null?fmt(bf,1)+'<small>%</small>':'—')+'</span>'+(bf!=null?'<span class="dl muted">'+bfLabel(bf)+'</span>':'<span class="dl muted">Sem registro</span>')+'</div>'+
   '<div class="stat"><span class="lab">Massa magra</span><span class="num">'+(mmv!=null?fmt(mmv,1)+'<small>kg</small>':'—')+'</span>'+(last?dl('mm'):'')+'</div>'+
   '<div class="stat"><span class="lab">IMC</span><span class="num">'+fmt(imc,1)+'</span><span class="dl muted">'+imcLabel(imc)+'</span></div>'+
   '</div></article></div>';
  const m=BM.find(x=>x[0]===ui.bm)||BM[0],cut=ui.br?Date.now()-ui.br*864e5:0;
  const pts=S.body.map(b=>({t:parse(b.d).getTime(),y:bodyVal(b,m[0])})).filter(x=>x.y!=null&&x.t>=cut);
  const goal=m[0]==='kg'?p.pesoMeta:m[0]==='bf'?p.gorduraMeta:0;
  h+='<div class="s8"><article class="card"><div class="chips" style="margin-bottom:12px">'+BM.map(x=>'<button class="chip'+(x[0]===ui.bm?' on':'')+'" data-a="bm" data-k="'+x[0]+'">'+x[1]+'</button>').join('')+'</div>'+
   '<h2 class="lab"><span>'+m[1]+' ('+m[2]+')</span><span class="chips">'+[[30,'30 d'],[90,'90 d'],[365,'1 ano'],[0,'Tudo']].map(x=>'<button class="chip'+(x[0]===ui.br?' on':'')+'" data-a="br" data-n="'+x[0]+'">'+x[1]+'</button>').join('')+'</span></h2>'+
   chart(W=>svgLine(W,260,pts,{goal:goal||0,ml:46}),260)+'</article></div>';
  h+='<div class="s4"><article class="card"><h2 class="lab"><span>Nova medição</span></h2><form id="bform" autocomplete="off"><div class="fgrid">'+
   '<label class="fld"><span>Data</span><input class="inp" id="bd" type="date" value="'+TODAY()+'"></label>'+
   [['bkg','Peso (kg)'],['bbf','Gordura (%)'],['bcin','Cintura (cm)'],['bpes','Pescoço (cm)'],['bqua','Quadril (cm)'],['bpei','Peito (cm)'],['bbra','Braço (cm)'],['bcox','Coxa (cm)'],['bpan','Panturrilha (cm)']].map(f=>'<label class="fld"><span>'+f[1]+'</span><input class="inp" id="'+f[0]+'" inputmode="decimal"></label>').join('')+
   '</div><div class="row" style="margin-top:16px"><button class="btn" type="submit">Salvar medição</button><button class="btn sec" type="button" data-a="navy">Estimar gordura</button></div>'+
   '<p class="note" style="margin-top:10px">A estimativa usa o método da Marinha dos EUA: cintura e pescoço (e quadril para mulheres). Margem de erro de alguns pontos percentuais.</p></form></article></div>';
  const rows=S.body.slice().reverse().slice(0,20);
  h+='<div class="s12"><article class="card"><h2 class="lab"><span>Histórico</span></h2>'+(rows.length?'<div class="scroll-x"><table class="tbl"><thead><tr><th>Data</th><th>Peso</th><th>Gordura</th><th>Massa magra</th><th>Cintura</th><th>Peito</th><th>Braço</th><th>Coxa</th><th></th></tr></thead><tbody>'+
   rows.map(b=>{const f=(k,d)=>{const v=bodyVal(b,k);return v==null?'—':fmt(v,d==null?1:d)};return '<tr><td>'+b.d.split('-').reverse().join('/')+'</td><td>'+f('kg')+' kg</td><td>'+f('bf')+(b.bf!=null&&b.bf!==''?' %':'')+'</td><td>'+f('mm')+'</td><td>'+f('cintura')+'</td><td>'+f('peito')+'</td><td>'+f('braco')+'</td><td>'+f('coxa')+'</td><td><button class="ib" aria-label="Excluir medição" data-a="del-body" data-d="'+b.d+'">×</button></td></tr>'}).join('')+'</tbody></table></div>':'<div class="empty">Nenhuma medição ainda. Registre seu peso acima.</div>')+'</article></div></div>';
  return h}

/* ---------- perfil ---------- */
function vPerfil(){
  const p=S.profile,g=calc();
  const f=(id,l,v,extra)=>'<label class="fld"><span>'+l+'</span><input class="inp" id="'+id+'" data-a="pf" data-f="'+id+'" inputmode="decimal" value="'+esc(v)+'" '+(extra||'')+'></label>';
  const sel=(id,l,opts,v)=>'<label class="fld"><span>'+l+'</span><select class="sel" id="'+id+'" data-a="pf" data-f="'+id+'">'+opts.map(o=>'<option value="'+o[0]+'"'+(String(o[0])===String(v)?' selected':'')+'>'+o[1]+'</option>').join('')+'</select></label>';
  let h='<div class="page-h"><h1 class="display">Perfil</h1></div>'+demoBar()+'<div class="grid"><div class="s7 stack">'+
  '<article class="card"><h2 class="lab"><span>Seus dados</span></h2><div class="fgrid w2">'+
   '<label class="fld"><span>Nome</span><input class="inp" id="nome" data-a="pf" data-f="nome" value="'+esc(p.nome)+'" maxlength="30"></label>'+
   sel('sexo','Sexo (para o cálculo)',[['m','Masculino'],['f','Feminino']],p.sexo)+f('idade','Idade',p.idade)+f('altura','Altura (cm)',p.altura)+f('peso','Peso inicial (kg)',p.peso)+
   sel('atividade','Nível de atividade',ACT,p.atividade)+'</div></article>'+
  '<article class="card"><h2 class="lab"><span>Objetivo</span></h2><div class="fgrid w2">'+
   sel('objetivo','Objetivo',Object.keys(OBJ).map(k=>[k,OBJ[k]]),p.objetivo)+f('pesoMeta','Peso meta (kg)',p.pesoMeta||'')+f('gorduraMeta','Gordura meta (%)',p.gorduraMeta||'')+
   sel('descanso','Descanso entre séries',[[45,'45 s'],[60,'60 s'],[90,'90 s'],[120,'2 min'],[180,'3 min']],p.descanso)+'</div></article>'+
  '<article class="card"><h2 class="lab"><span>Seus dados no app</span></h2><div class="row"><button class="btn sec" data-a="export">Baixar backup</button><button class="btn sec" data-a="import-open">Restaurar backup</button><button class="btn dng" data-a="reset">Apagar tudo</button></div><div id="bk"></div></article></div>'+
  '<div class="s5 stack"><article class="card"><h2 class="lab"><span>Metas diárias</span><label class="row sm" style="gap:6px"><input type="checkbox" id="manual" data-a="pf" data-f="manual"'+(p.manual?' checked':'')+'> Ajustar manualmente</label></h2>'+
   '<div class="kv" style="margin-bottom:16px"><div><b>'+fmt(g.bmr)+'</b><span>Metabolismo basal</span></div><div><b>'+fmt(g.tdee)+'</b><span>Gasto diário</span></div><div><b>'+fmt(g.agua/1000,2)+' L</b><span>Água</span></div></div>'+
   '<div class="fgrid">'+[['kcal','Calorias',g.kcal],['prot','Proteína (g)',g.prot],['carb','Carbo (g)',g.carb],['fat','Gordura (g)',g.fat]].map(a=>'<label class="fld"><span>'+a[1]+'</span><input class="inp" id="m_'+a[0]+'" data-a="mf" data-f="'+a[0]+'" inputmode="numeric" value="'+a[2]+'"'+(p.manual?'':' disabled')+'></label>').join('')+'</div>'+
   '<p class="note" style="margin-top:12px">Cálculo automático: fórmula de Mifflin-St Jeor, déficit de 20% para perder gordura, superávit de 10% para ganhar massa, proteína de 1,9 a 2,2 g/kg.</p></article></div></div>';
  return h}

/* ---------- render ---------- */
const VIEWS={hoje:vHoje,refeicoes:vRef,treinos:vTre,corpo:vCorpo,perfil:vPerfil};
let navBuilt=false;
function render(){
  CH=[];chN=0;const r=route();
  if(!navBuilt){navBuilt=true;
    $('#nav').innerHTML=ROUTES.map(x=>'<a href="#'+x[0]+'" data-r="'+x[0]+'">'+x[1]+'</a>').join('');
    $('#tabbar .in').innerHTML=ROUTES.map(x=>'<a href="#'+x[0]+'" data-r="'+x[0]+'">'+ico(x[2])+x[1]+'</a>').join('')}
  document.querySelectorAll('[data-r]').forEach(a=>{const on=a.dataset.r===r;a.classList.toggle('on',on);if(on)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')});
  $('#topDate').textContent=dlabel(TODAY());
  $('#view').innerHTML=VIEWS[r]();
  drawCharts();
}
let tt=null;
function toast(m){const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(tt);tt=setTimeout(()=>{t.hidden=true},2600)}

/* ---------- pop-ups ---------- */
function openSheet(html){const o=$('#ov');o.innerHTML='<div class="bg" data-a="close"></div><div class="sheet" role="dialog" aria-modal="true">'+html+'</div>';o.hidden=false;document.body.classList.add('lock')}
function closeSheet(){const o=$('#ov');o.hidden=true;o.innerHTML='';document.body.classList.remove('lock');ui.fm=null;ui.we=null;ui.sx=false}
const shHead=t=>'<div class="sh-h"><h3>'+t+'</h3><button class="ib" data-a="close" aria-label="Fechar">×</button></div>';

function openFood(slot){
  ui.fm={slot:slot,list:allFoods(),sel:null};
  openSheet(shHead('Adicionar alimento')+'<label class="fld"><span>Buscar</span><input class="inp" id="fq" placeholder="Ex.: arroz, frango, banana" autocomplete="off"></label><div class="flist" id="flist"></div><div id="fsel"></div><div class="row"><button class="btn sec sm" data-a="new-food">Criar alimento</button></div>');
  foodList('');setTimeout(()=>{const q=$('#fq');if(q)q.focus()},50)}
function foodList(q){
  const n=norm(q.trim()),L=ui.fm.list,out=[];
  for(let i=0;i<L.length&&out.length<60;i++)if(!n||norm(L[i].n).indexOf(n)>=0)out.push(i);
  $('#flist').innerHTML=out.length?out.map(i=>'<button class="frow" data-a="pick" data-i="'+i+'">'+esc(L[i].n)+'<span>'+L[i].k+' kcal / 100 g</span></button>').join(''):'<div class="empty">Nada encontrado. Use "Criar alimento".</div>'}
function foodPrev(){
  const f=ui.fm.sel,g=num($('#fg').value)||0,m=mk(f,g);
  $('#fprev').innerHTML='<div><b>'+m.k+'</b><span>KCAL</span></div><div><b>'+fmt(m.p,1)+'</b><span>PROT</span></div><div><b>'+fmt(m.c,1)+'</b><span>CARBO</span></div><div><b>'+fmt(m.f,1)+'</b><span>GORD</span></div>';
  $('#fadd').disabled=g<=0}
function pickFood(i){
  const f=ui.fm.list[i];ui.fm.sel=f;
  $('#flist').hidden=true;$('#fq').closest('label').hidden=true;
  $('#fsel').innerHTML='<div class="stack"><div><div class="sub" style="padding-left:0">Selecionado</div><div style="font-weight:700;font-size:18px">'+esc(f.n)+'</div></div>'+
   '<label class="fld"><span>Quantidade (g)</span><input class="inp" id="fg" inputmode="decimal" value="'+(f.ug||100)+'"></label>'+
   (f.ug?'<div class="chips"><button class="chip" data-a="gq" data-g="'+f.ug+'">1 '+esc(f.ul)+' ('+f.ug+' g)</button><button class="chip" data-a="gq" data-g="'+f.ug*2+'">2 '+esc(f.ul)+'</button><button class="chip" data-a="gq" data-g="100">100 g</button></div>':'<div class="chips"><button class="chip" data-a="gq" data-g="50">50 g</button><button class="chip" data-a="gq" data-g="100">100 g</button><button class="chip" data-a="gq" data-g="200">200 g</button></div>')+
   '<div class="prev" id="fprev"></div><div class="row"><button class="btn sec" data-a="fback">Voltar</button><button class="btn" id="fadd" data-a="food-ok">Adicionar</button></div></div>';
  foodPrev()}
function newFoodForm(){
  $('#fsel').innerHTML='<div class="stack"><div class="sub" style="padding-left:0">Novo alimento (valores por 100 g)</div><label class="fld"><span>Nome</span><input class="inp" id="cn" maxlength="50"></label><div class="fgrid"><label class="fld"><span>Calorias</span><input class="inp" id="ck" inputmode="decimal"></label><label class="fld"><span>Proteína (g)</span><input class="inp" id="cp" inputmode="decimal"></label><label class="fld"><span>Carbo (g)</span><input class="inp" id="cc" inputmode="decimal"></label><label class="fld"><span>Gordura (g)</span><input class="inp" id="cf" inputmode="decimal"></label></div><div class="row"><button class="btn sec" data-a="fback">Voltar</button><button class="btn" data-a="food-new-ok">Salvar alimento</button></div></div>';
  $('#flist').hidden=true;$('#fq').closest('label').hidden=true}

function openWE(id){
  const w=id==='new'?{id:'w'+uid(),nome:'',foco:'',ex:[],isNew:true}:clone(S.plans.workouts.find(x=>x.id===id));
  ui.we=w;drawWE()}
function drawWE(){
  const w=ui.we;
  openSheet(shHead(w.isNew?'Novo treino':'Editar treino')+'<label class="fld"><span>Nome</span><input class="inp" id="wn" data-a="we" data-f="nome" value="'+esc(w.nome)+'" maxlength="40" placeholder="Ex.: Peito + Tríceps"></label><label class="fld"><span>Foco</span><input class="inp" id="wf" data-a="we" data-f="foco" value="'+esc(w.foco)+'" maxlength="40" placeholder="Ex.: Empurrar"></label>'+
   '<div>'+w.ex.map((e,i)=>'<div class="wex"><div class="nm">'+esc(e.n)+'</div><input aria-label="Séries" inputmode="numeric" data-a="wex" data-i="'+i+'" data-f="s" value="'+e.s+'"><input aria-label="Repetições" data-a="wex" data-i="'+i+'" data-f="r" value="'+esc(e.r)+'"><button class="ib" aria-label="Remover" data-a="wex-rm" data-i="'+i+'">×</button></div>').join('')+(w.ex.length?'<p class="note" style="margin-top:6px">Colunas: séries e repetições.</p>':'<div class="empty">Nenhum exercício ainda.</div>')+'</div>'+
   '<label class="fld"><span>Adicionar exercício</span><select class="sel" id="wsel">'+exOpts()+'</select></label><div class="row"><button class="btn sec sm" data-a="wex-add">+ Adicionar</button></div>'+
   '<div class="row"><button class="btn" data-a="we-save">Salvar treino</button>'+(w.isNew?'':'<button class="btn dng" data-a="we-del">Excluir</button>')+'</div>')}
const exOpts=()=>GROUPS.map(g=>'<optgroup label="'+g+'">'+EXL[g].map(n=>'<option value="'+esc(n)+'">'+esc(n)+'</option>').join('')+'</optgroup>').join('');
function openSX(){
  ui.sx=true;
  openSheet(shHead('Adicionar exercício')+'<label class="fld"><span>Exercício</span><select class="sel" id="xsel">'+exOpts()+'</select></label><label class="fld"><span>Ou digite um nome</span><input class="inp" id="xcus" maxlength="50"></label><div class="row"><button class="btn" data-a="sx-ok">Adicionar ao treino</button></div>')}

/* ---------- sessão de treino ---------- */
const saveSes=()=>{try{if(ui.ses)localStorage.setItem(LSS,JSON.stringify(ui.ses));else localStorage.removeItem(LSS)}catch(e){}};
function startSes(wid){
  const w=S.plans.workouts.find(x=>x.id===wid);
  ui.ses={d:TODAY(),wid:wid,nome:w?w.nome:'Treino livre',start:Date.now(),ex:w?w.ex.map(e=>({n:e.n,g:e.g,r:e.r,sets:Array.from({length:e.s},()=>({kg:'',r:'',ok:false}))})):[]};
  ui.tt='sessao';saveSes();if(route()!=='treinos')location.hash='#treinos';else render()}
function finishSes(){
  const s=ui.ses,ex=[];
  s.ex.forEach(e=>{const sets=e.sets.map(x=>({kg:num(x.kg),r:num(x.r),ok:x.ok})).filter(x=>x.kg!=null&&x.r!=null&&x.r>0&&(x.ok||true)).map(x=>({kg:x.kg,r:Math.round(x.r)}));
    if(sets.length)ex.push({n:e.n,g:e.g,sets:sets})});
  if(!ex.length){toast('Registre ao menos uma série com carga e repetições.');return}
  let prs=0;ex.forEach(e=>{const b=bestE1(e.n,s.d),m=Math.max.apply(null,e.sets.map(x=>e1rm(x.kg,x.r)));if(b>0&&m>b+.01)prs++});
  const vol=Math.round(ex.reduce((a,e)=>a+e.sets.reduce((b,x)=>b+x.kg*x.r,0),0));
  S.logs.push({id:uid(),d:s.d,wid:s.wid,nome:s.nome,dur:Math.max(1,Math.round((Date.now()-s.start)/6e4)),vol:vol,ex:ex});
  S.logs.sort((a,b)=>a.d<b.d?-1:a.d>b.d?1:0);save('logs-'+s.d.slice(0,4));
  ui.ses=null;saveSes();stopRest();toast(prs?'Treino salvo. '+prs+(prs>1?' novos recordes!':' novo recorde!'):'Treino salvo.');render()}
function startRest(){rest={end:Date.now()+S.profile.descanso*1000};tickRest()}
function stopRest(){rest=null;$('#restbar').hidden=true}
function tickRest(){
  const rb=$('#restbar');if(!rest){rb.hidden=true;return}
  const left=Math.ceil((rest.end-Date.now())/1000);
  if(left<=0){stopRest();toast('Descanso terminado.');return}
  rb.hidden=false;rb.innerHTML='<span class="eyebrow" style="color:var(--hero-mut)">Descanso</span><span class="num tn">'+Math.floor(left/60)+':'+pad(left%60)+'</span><button data-a="rest-add">+15 s</button><button data-a="rest-stop">Pular</button>'}
setInterval(()=>{if(rest)tickRest()},500);

/* ---------- ações ---------- */
function setP(f,v){
  const p=S.profile,numF={idade:1,altura:1,peso:1,pesoMeta:1,gorduraMeta:1,descanso:1,atividade:1};
  if(f==='manual'){p.manual=!!v;if(p.manual){const a=calc().auto;p.kcal=a.kcal;p.prot=a.prot;p.carb=a.carb;p.fat=a.fat}}
  else if(numF[f]){const n=num(v);p[f]=n==null?(f==='pesoMeta'||f==='gorduraMeta'?0:p[f]):n}
  else p[f]=v;
  save('core')}
const A={
 close:()=>closeSheet(),
 water:(el)=>{const d=el.dataset.d,v=Math.max(0,(S.water[d]||0)+Number(el.dataset.n));S.water[d]=v;save('m-'+d.slice(0,7));render()},
 'rm-food':(el)=>{const d=el.dataset.d;S.meals[d][el.dataset.s].splice(Number(el.dataset.i),1);save('m-'+d.slice(0,7));render()},
 'add-food':(el)=>openFood(el.dataset.s),
 dnav:(el)=>{const n=Number(el.dataset.n);ui.mealDate=n===0?TODAY():addDays(ui.mealDate||TODAY(),n);render()},
 pick:(el)=>pickFood(Number(el.dataset.i)),
 gq:(el)=>{$('#fg').value=el.dataset.g;foodPrev()},
 fback:()=>{$('#fsel').innerHTML='';$('#flist').hidden=false;$('#fq').closest('label').hidden=false;ui.fm.sel=null},
 'new-food':()=>newFoodForm(),
 'food-ok':()=>{
   const g=num($('#fg').value);if(!g||g<=0)return;const d=ui.mealDate||TODAY(),sl=ui.fm.slot;
   S.meals[d]=S.meals[d]||{};S.meals[d][sl]=S.meals[d][sl]||[];S.meals[d][sl].push(mk(ui.fm.sel,g));
   save('m-'+d.slice(0,7));closeSheet();render();toast('Alimento adicionado.')},
 'food-new-ok':()=>{
   const n=$('#cn').value.trim(),k=num($('#ck').value);
   if(!n||k==null){toast('Informe o nome e as calorias.');return}
   S.customFoods.push({n:n,k:k,p:num($('#cp').value)||0,c:num($('#cc').value)||0,f:num($('#cf').value)||0});save('core');
   ui.fm.list=allFoods();$('#fsel').innerHTML='';$('#flist').hidden=false;$('#fq').closest('label').hidden=false;$('#fq').value=n;foodList(n);toast('Alimento criado.')},
 tt:(el)=>{ui.tt=el.dataset.t;render()},
 start:(el)=>{if(ui.ses&&!confirmSwap(el))return;startSes(el.dataset.w)},
 'cancel-ses':(el)=>{if(el.dataset.c){ui.ses=null;saveSes();stopRest();render()}else{el.dataset.c='1';el.textContent='Confirmar cancelamento'}},
 finish:()=>finishSes(),
 chk:(el)=>{const e=ui.ses.ex[el.dataset.i],x=e.sets[el.dataset.j],last=lastSets(e.n);
   x.ok=!x.ok;if(x.ok){if(x.kg===''){const l=last&&(last[el.dataset.j]||last[last.length-1]);if(l)x.kg=l.kg}if(x.r===''){const l=last&&(last[el.dataset.j]||last[last.length-1]);if(l)x.r=l.r}startRest()}
   saveSes();render()},
 'add-set':(el)=>{ui.ses.ex[el.dataset.i].sets.push({kg:'',r:'',ok:false});saveSes();render()},
 'rm-sx':(el)=>{ui.ses.ex.splice(el.dataset.i,1);saveSes();render()},
 'add-sx':()=>openSX(),
 'sx-ok':()=>{const n=($('#xcus').value.trim())||$('#xsel').value;ui.ses.ex.push({n:n,g:exGroup(n),r:'',sets:[{kg:'',r:'',ok:false},{kg:'',r:'',ok:false},{kg:'',r:'',ok:false}]});saveSes();closeSheet();render()},
 'edit-w':(el)=>openWE(el.dataset.w),'new-w':()=>openWE('new'),
 'wex-add':()=>{const n=$('#wsel').value;ui.we.ex.push({n:n,g:exGroup(n),s:3,r:'8-12'});drawWE()},
 'wex-rm':(el)=>{ui.we.ex.splice(el.dataset.i,1);drawWE()},
 'we-save':()=>{const w=ui.we;if(!w.nome.trim()){toast('Dê um nome ao treino.');return}
   const o={id:w.id,nome:w.nome.trim(),foco:(w.foco||'').trim(),ex:w.ex.map(e=>({n:e.n,g:e.g,s:Math.max(1,Math.round(num(e.s)||3)),r:String(e.r||'8-12')}))};
   const i=S.plans.workouts.findIndex(x=>x.id===w.id);if(i>=0)S.plans.workouts[i]=o;else S.plans.workouts.push(o);save('core');closeSheet();render()},
 'we-del':(el)=>{if(el.dataset.c){const id=ui.we.id;S.plans.workouts=S.plans.workouts.filter(x=>x.id!==id);S.plans.week=S.plans.week.map(x=>x===id?'':x);save('core');closeSheet();render()}else{el.dataset.c='1';el.textContent='Confirmar exclusão'}},
 'del-log':(el)=>{if(el.dataset.c){const l=S.logs.find(x=>x.id===el.dataset.id);S.logs=S.logs.filter(x=>x.id!==el.dataset.id);if(l)save('logs-'+l.d.slice(0,4));render()}else{el.dataset.c='1';el.textContent='Confirmar exclusão'}},
 bm:(el)=>{ui.bm=el.dataset.k;render()},
 br:(el)=>{ui.br=Number(el.dataset.n);render()},
 navy:()=>{const p=S.profile,v=navy(p.sexo,p.altura,num($('#bcin').value),num($('#bpes').value),num($('#bqua').value));
   if(v==null||v<2||v>60){toast(p.sexo==='m'?'Informe cintura e pescoço.':'Informe cintura, pescoço e quadril.');return}
   $('#bbf').value=fmt(v,1).replace(',','.');toast('Estimativa preenchida. Confira e salve.')},
 'del-body':(el)=>{S.body=S.body.filter(b=>b.d!==el.dataset.d);save('body');render()},
 'clear-demo':()=>{const keep=S.profile;S=blank();S.profile.altura=keep.altura;S.profile.idade=keep.idade;S.profile.sexo=keep.sexo;S.plans=defaultPlans();allKeys().forEach(k=>dirty.add(k));save('core','body');render();toast('Pronto. Agora é com você.')},
 'rest-add':()=>{if(rest){rest.end+=15000;tickRest()}},'rest-stop':()=>stopRest(),
 export:async()=>{
   const data=JSON.stringify(S,null,1);
   try{const d=await window.claude.use('downloads');if(d){await d.save({filename:'forma-backup-'+TODAY()+'.json',data:data});toast('Backup salvo.');return}}catch(e){if(e&&e.code==='declined')return}
   $('#bk').innerHTML='<p class="note" style="margin:14px 0 6px">Copie o texto abaixo e guarde em um lugar seguro.</p><textarea class="inp" id="bkt" readonly></textarea>';$('#bkt').value=data;$('#bkt').select()},
 'import-open':()=>{$('#bk').innerHTML='<p class="note" style="margin:14px 0 6px">Cole aqui o texto do backup. Isso substitui os dados atuais.</p><textarea class="inp" id="bkt" placeholder="Cole o backup"></textarea><div class="row" style="margin-top:10px"><button class="btn" data-a="import-ok">Restaurar</button></div>'},
 'import-ok':()=>{try{const o=JSON.parse($('#bkt').value);if(!o||!o.profile||!o.plans)throw 0;S=Object.assign(blank(),o);S.demo=false;allKeys().forEach(k=>dirty.add(k));save('core');render();toast('Backup restaurado.')}catch(e){toast('Esse texto não é um backup válido.')}},
 reset:(el)=>{if(el.dataset.c){S=blank();if(dbCol)known.forEach(k=>{if(!allKeys().has(k))dbCol.doc(k).delete().catch(()=>{})});save('core','body');render();toast('Dados apagados.')}else{el.dataset.c='1';el.textContent='Toque de novo para apagar tudo'}}
};
function confirmSwap(el){if(el.dataset.c)return true;el.dataset.c='1';toast('Já existe um treino em andamento. Toque de novo para trocar.');return false}

document.addEventListener('click',e=>{
  const el=e.target.closest('[data-a]');if(!el)return;
  const a=el.dataset.a;if(A[a]&&el.tagName!=='INPUT'&&el.tagName!=='SELECT'){e.preventDefault();A[a](el)}});
document.addEventListener('input',e=>{
  const el=e.target,a=el.dataset&&el.dataset.a;
  if(el.id==='fq'&&ui.fm){foodList(el.value);return}
  if(el.id==='fg'&&ui.fm&&ui.fm.sel){foodPrev();return}
  if(a==='si'){const x=ui.ses.ex[el.dataset.i].sets[el.dataset.j];x[el.dataset.f]=el.value;saveSes()}
  else if(a==='we'){ui.we[el.dataset.f]=el.value}
  else if(a==='wex'){ui.we.ex[el.dataset.i][el.dataset.f]=el.value}
  else if(a==='pf'&&el.type!=='checkbox'&&el.tagName==='INPUT'&&el.id==='nome'){setP('nome',el.value)}});
document.addEventListener('change',e=>{
  const el=e.target,a=el.dataset&&el.dataset.a;
  if(el.id==='mdate'){if(el.value){ui.mealDate=el.value;render()}return}
  if(a==='wk'){S.plans.week[Number(el.dataset.di)]=el.value;save('core');return}
  if(a==='exsel'){ui.exSel=el.value;render();return}
  if(a==='pf'){setP(el.dataset.f,el.type==='checkbox'?el.checked:el.value);if(el.dataset.f!=='nome')render();return}
  if(a==='mf'){const n=num(el.value);if(n!=null){S.profile[el.dataset.f]=Math.round(n);save('core')}render()}});
document.addEventListener('submit',e=>{
  if(e.target.id!=='bform')return;e.preventDefault();
  const o={d:$('#bd').value||TODAY()},m={kg:'bkg',bf:'bbf',cintura:'bcin',pescoco:'bpes',quadril:'bqua',peito:'bpei',braco:'bbra',coxa:'bcox',panturrilha:'bpan'};
  let any=false;for(const k in m){const v=num($('#'+m[k]).value);if(v!=null){o[k]=v;any=true}}
  if(!any){toast('Preencha ao menos um campo.');return}
  const i=S.body.findIndex(b=>b.d===o.d);if(i>=0)S.body[i]=Object.assign(S.body[i],o);else S.body.push(o);
  S.body.sort((a,b)=>a.d<b.d?-1:a.d>b.d?1:0);save('body');render();toast('Medição salva.')});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#ov').hidden)closeSheet()});
window.addEventListener('hashchange',()=>{window.scrollTo(0,0);render()});
let rz=null;window.addEventListener('resize',()=>{clearTimeout(rz);rz=setTimeout(drawCharts,150)});

/* ---------- início ---------- */
try{const raw=localStorage.getItem(LS);if(raw){S=Object.assign(blank(),JSON.parse(raw));S.profile=Object.assign(blank().profile,S.profile)}}catch(e){}
if(!S)S=demo();
try{const r=localStorage.getItem(LSS);if(r)ui.ses=JSON.parse(r)}catch(e){}
render();connect();
})();
