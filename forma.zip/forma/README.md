# Forma

Painel pessoal de fitness em português: refeições (calorias e macros), água, peso, gordura corporal, medidas e treinos de musculação com progressão de carga.

Site estático, sem build e sem dependências. Os dados ficam no navegador (`localStorage`).

## Telas

- **Hoje**: resumo do dia, semana de treinos, gráficos de peso e volume.
- **Refeições**: cinco refeições por dia, cerca de 90 alimentos brasileiros e alimentos personalizados.
- **Treinos**: planos editáveis, registro de séries com cronômetro de descanso, histórico e progressão (1RM estimado, recordes).
- **Corpo**: peso, % de gordura, massa magra, IMC, medidas e estimativa de gordura pelo método da Marinha.
- **Perfil**: metas diárias (Mifflin-St Jeor), objetivo, backup e restauração em JSON.

## Rodar localmente

Abra o `index.html` no navegador, ou sirva a pasta:

```bash
python3 -m http.server 8000
```

## Publicar no GitHub Pages

1. Crie um repositório e envie estes arquivos para a branch `main`.
2. Em **Settings → Pages**, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`.
3. O site fica em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.

## Observações

- O app abre com dados de exemplo; o botão "Começar do zero" limpa tudo.
- Os dados ficam só no navegador em que você usa. Use **Perfil → Baixar backup** para guardar uma cópia.
- As fontes (Archivo e Barlow Condensed) vêm do Google Fonts. Sem internet, o app usa fontes do sistema.
